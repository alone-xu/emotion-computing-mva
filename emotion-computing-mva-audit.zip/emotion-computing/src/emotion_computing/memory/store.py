"""④ 记忆层 · 存储。

实现需求 M-1 ~ M-3、M-5、M-6。

存储布局（全部位于 data/ 下）::

    data/
      episodes.jsonl   # 一行一个 Episode（主存储，人类可读，追加写）
      index.jsonl      # 一行一个聚合特征向量（检索加速）
      profile.json     # 跨会话个体画像（M-5 回写）
      reports/
        <episode_id>.md  # 复盘报告

为什么用 JSONL 而不是数据库：MVA 阶段的可读性与可调试性 > 查询性能；
任何一行都能用文本编辑器看懂，出问题时可人工核查。
"""

from __future__ import annotations

import json
import math
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from ..config import load_profile, save_profile
from ..contracts import Episode, PersonalProfile


def _now_iso() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def _slope(times: list[float], values: list[float]) -> float:
    """简单线性斜率（每分钟）；用于聚合特征，不追求稳健性。"""
    n = len(times)
    if n < 2:
        return 0.0
    dt = times[-1] - times[0]
    if dt <= 1e-6:
        return 0.0
    return (values[-1] - values[0]) / dt * 60.0


def summarize(episode: Episode) -> dict:
    """从 Episode 的样本序列中提取聚合统计量（供检索、复盘、回写使用）。"""
    samples = episode.samples or []
    values = [float(s.get("smoothed", 0.0)) for s in samples]
    times = [float(s.get("t", 0.0)) for s in samples]
    confs = [float(s.get("confidence", 0.0)) for s in samples]
    n = len(values)

    if n == 0:
        return {
            "mean": 0.0, "max": 0.0, "min": 0.0, "std": 0.0,
            "n_samples": 0, "n_spikes": 0, "n_events": 0,
            "duration_min": 0.0, "peak_time_ratio": 0.0,
            "slope_early": 0.0, "slope_late": 0.0,
            "recovery_time": None, "mean_confidence": 0.0,
            "n_interventions": 0,
        }

    mean = sum(values) / n
    std = math.sqrt(sum((v - mean) ** 2 for v in values) / n)
    peak_idx = max(range(n), key=lambda i: values[i])
    duration = times[-1] - times[0] if n > 1 else 0.0

    half = max(n // 2, 1)
    slope_early = _slope(times[:half], values[:half])
    slope_late = _slope(times[half:], values[half:])

    # 恢复时间：峰值之后首次回落到 baseline 与峰值中点所需的时间
    recovery_time = None
    if n > 1:
        baseline = float(episode.baseline_mu)
        half_level = baseline + 0.5 * (values[peak_idx] - baseline)
        for i in range(peak_idx + 1, n):
            if values[i] <= half_level:
                recovery_time = float(times[i] - times[peak_idx])
                break

    events = episode.events or []
    return {
        "mean": float(mean),
        "max": float(values[peak_idx]),
        "min": float(min(values)),
        "std": float(std),
        "n_samples": n,
        "n_spikes": sum(1 for e in events if e.get("kind") == "spike"),
        "n_events": len(events),
        "duration_min": float(duration / 60.0),
        "peak_time_ratio": float(peak_idx / max(n - 1, 1)),
        "slope_early": float(slope_early),
        "slope_late": float(slope_late),
        "recovery_time": recovery_time,
        "mean_confidence": float(sum(confs) / n),
        "n_interventions": len(episode.interventions or []),
    }


class EpisodeStore:
    def __init__(self, data_dir: str | Path = "data") -> None:
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.episodes_path = self.data_dir / "episodes.jsonl"
        self.index_path = self.data_dir / "index.jsonl"
        self.profile_path = self.data_dir / "profile.json"
        self.reports_dir = self.data_dir / "reports"
        self.reports_dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    def new_episode(self, task_label: str = "default") -> Episode:
        return Episode(
            episode_id=uuid.uuid4().hex[:12],
            started_at=_now_iso(),
            task_label=task_label,
        )

    # ------------------------------------------------------------------
    def append_episode(self, episode: Episode) -> Path:
        episode.ended_at = _now_iso()
        with self.episodes_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(episode.as_dict(), ensure_ascii=False) + "\n")
        self._append_index(episode)
        return self.episodes_path

    def _append_index(self, episode: Episode) -> None:
        summary = episode.summary or summarize(episode)
        record = {
            "episode_id": episode.episode_id,
            "task_label": episode.task_label,
            "started_at": episode.started_at,
            "task_outcome": episode.task_outcome,
            **summary,
        }
        with self.index_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(record, ensure_ascii=False) + "\n")

    # ------------------------------------------------------------------
    def load_all(self) -> list[Episode]:
        if not self.episodes_path.exists():
            return []
        out: list[Episode] = []
        for line in self.episodes_path.read_text("utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                out.append(Episode.from_dict(json.loads(line)))
            except (json.JSONDecodeError, TypeError):
                continue
        return out

    def load(self, episode_id: str) -> Episode | None:
        for ep in self.load_all():
            if ep.episode_id == episode_id:
                return ep
        return None

    def load_index(self) -> list[dict]:
        if not self.index_path.exists():
            return []
        rows: list[dict] = []
        for line in self.index_path.read_text("utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError:
                continue
        return rows

    # ------------------------------------------------------------------
    def write_report(self, episode_id: str, markdown: str) -> Path:
        path = self.reports_dir / f"{episode_id}.md"
        path.write_text(markdown, encoding="utf-8")
        return path

    # ------------------------------------------------------------------
    def load_profile(self) -> PersonalProfile:
        return load_profile(self.profile_path)

    def save_profile(self, profile: PersonalProfile) -> None:
        save_profile(self.profile_path, profile)

    # ------------------------------------------------------------------
    def clear(self) -> None:
        """清空所有记忆产物（需求文档：数据可一键删除）。"""
        for p in (self.episodes_path, self.index_path, self.profile_path):
            if p.exists():
                p.unlink()
        if self.reports_dir.exists():
            for f in self.reports_dir.iterdir():
                if f.is_file():
                    f.unlink()
