"""④ 记忆层 · 相似情境检索。

实现需求 M-3。

MVA 阶段刻意只用**统计相似度**（标准化后的欧氏距离 + 任务标签约束），
不引入向量数据库或嵌入模型 —— 会话数量在这个阶段很小，
可解释性与零依赖比检索精度更重要。
"""

from __future__ import annotations

from typing import Sequence

import numpy as np

from ..contracts import Episode
from .store import summarize

#: 参与相似度计算的数值特征（顺序固定，不要随意插队）
FEATURE_KEYS: tuple[str, ...] = (
    "mean",
    "max",
    "std",
    "slope_early",
    "slope_late",
    "peak_time_ratio",
    "n_spikes",
    "duration_min",
)


def episode_feature_vector(episode: Episode) -> list[float]:
    summary = episode.summary or summarize(episode)
    return [float(summary.get(k, 0.0) or 0.0) for k in FEATURE_KEYS]


def find_similar(
    index_rows: Sequence[dict],
    query_features: Sequence[float],
    task_label: str | None = None,
    top_k: int = 3,
    exclude_id: str | None = None,
) -> list[dict]:
    """在历史索引中找最相似的情境。

    返回按相似度降序排列的记录，每条附加 ``distance`` 与 ``similarity``。
    """
    rows = [
        r
        for r in index_rows
        if (task_label is None or r.get("task_label") == task_label)
        and r.get("episode_id") != exclude_id
        and all(k in r for k in FEATURE_KEYS)
    ]
    if not rows:
        return []

    matrix = np.asarray([[float(r[k]) for k in FEATURE_KEYS] for r in rows], dtype=float)
    query = np.asarray(list(query_features), dtype=float)

    # 用历史分布的均值/标准差做标准化，避免量纲差异主导距离
    mu = matrix.mean(axis=0)
    sigma = matrix.std(axis=0)
    sigma[sigma < 1e-9] = 1.0

    z_rows = (matrix - mu) / sigma
    z_query = (query - mu) / sigma
    distances = np.linalg.norm(z_rows - z_query, axis=1)

    order = np.argsort(distances)[: max(top_k, 1)]
    max_d = float(distances[order[-1]]) if len(order) else 1.0
    out: list[dict] = []
    for idx in order:
        row = dict(rows[int(idx)])
        row["distance"] = float(distances[int(idx)])
        row["similarity"] = float(max(0.0, 1.0 - distances[int(idx)] / (max_d + 1e-9)))
        out.append(row)
    return out
