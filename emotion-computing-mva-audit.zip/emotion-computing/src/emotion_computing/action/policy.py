"""⑤ 行动层 · 分级决策与迟滞。

实现需求 A-1 ~ A-4、A-6。

迟滞的两个机制（架构文档 §5.5.1）：
  1. **冷却时间**：同一动作在 cooldown 内不重复输出；
  2. **阈值分离**：由慢系统状态机承担（theta_mid/theta_hi 之间留有带宽）。

被冷却抑制时返回 ``continue``，并在 rationale 中说明"已在冷却期"，
这样"系统为什么没说话"同样可追溯。
"""

from __future__ import annotations

from typing import Any

from ..contracts import ActionDecision, CapacityAssessment, StressSample
from .interventions import pick_intervention


class ActionPolicy:
    def __init__(self, config: Any, profile: Any = None) -> None:
        self.config = config
        self.profile = profile
        self._last_action_at: dict[str, float] = {}
        self._watch_since: float | None = None
        self._last_action: str = "continue"
        self._last_intervention_id: str | None = None

    # ------------------------------------------------------------------
    def _cooldown_for(self, action: str) -> float:
        cfg = self.config
        return {
            "coach": cfg.cooldown_coach,
            "micro_break": cfg.cooldown_micro_break,
            "pause": cfg.cooldown_pause,
        }.get(action, 0.0)

    def _in_cooldown(self, action: str, now: float) -> bool:
        last = self._last_action_at.get(action)
        if last is None:
            return False
        return (now - last) < self._cooldown_for(action)

    def _effectiveness(self) -> dict[str, float]:
        if self.profile is None:
            return {}
        return dict(getattr(self.profile, "intervention_effectiveness", {}) or {})

    # ------------------------------------------------------------------
    def decide(
        self,
        sample: StressSample,
        assessment: CapacityAssessment,
        now: float | None = None,
    ) -> ActionDecision:
        cfg = self.config
        now = float(now if now is not None else sample.timestamp)
        state = assessment.state

        # ---- 跟踪 WATCH 持续时长 ----
        if state == "WATCH":
            if self._watch_since is None:
                self._watch_since = now
        else:
            self._watch_since = None

        # ---- 候选动作 ----
        if state == "PAUSE":
            candidate = "pause"
        elif state == "WATCH":
            watched = (now - self._watch_since) if self._watch_since is not None else 0.0
            candidate = "micro_break" if watched >= cfg.t_watch else "coach"
        else:
            candidate = "continue"

        # ---- 迟滞：冷却抑制 ----
        if candidate != "continue" and self._in_cooldown(candidate, now):
            last = self._last_action_at.get(candidate, now)
            reason = (
                f"状态为 {state}，但动作 {candidate} 仍在冷却期"
                f"（剩余 {self._cooldown_for(candidate) - (now - last):.0f}s），本轮不重复提示。"
            )
            return ActionDecision(
                timestamp=now,
                action="continue",
                intervention=None,
                message="",
                rationale=reason,
                urgent=False,
            )

        # ---- 组装决策 ----
        if candidate == "continue":
            # 仅在"刚从高位回落"时给一次正向确认
            recovering = (
                self._last_action in ("coach", "micro_break", "pause")
                and sample.smoothed < cfg.theta_mid * 0.8
            )
            if recovering:
                intervention = pick_intervention(
                    "continue",
                    [f"{sample.smoothed:.2f}"],
                    self._effectiveness(),
                )
                self._last_action_at["continue"] = now
                self._last_action = "continue"
                self._last_intervention_id = intervention.id if intervention else None
                return ActionDecision(
                    timestamp=now,
                    action="continue",
                    intervention=intervention.id if intervention else None,
                    message=intervention.message if intervention else "",
                    rationale="紧张度已回落至关注阈值以下（需求 A-6：默认静默，仅在此时给予确认）。",
                    urgent=False,
                )
            return ActionDecision(
                timestamp=now,
                action="continue",
                intervention=None,
                message="",
                rationale=f"状态 {state}：紧张度 {sample.smoothed:.2f} 未见恶化。",
                urgent=False,
            )

        signals = [f"{sample.smoothed:.2f}", *assessment.reasons[:2]]
        intervention = pick_intervention(candidate, signals, self._effectiveness())

        rationale = "；".join(assessment.reasons[:3])
        message = intervention.message if intervention else ""
        if intervention:
            rationale = (
                f"{rationale}　→ 选择干预「{intervention.title}」："
                + intervention.rationale_template.format(signals=", ".join(signals[:2]))
            )

        self._last_action_at[candidate] = now
        self._last_action = candidate
        self._last_intervention_id = intervention.id if intervention else None

        return ActionDecision(
            timestamp=now,
            action=candidate,
            intervention=intervention.id if intervention else None,
            message=message,
            rationale=rationale,
            urgent=(candidate == "pause"),
        )
