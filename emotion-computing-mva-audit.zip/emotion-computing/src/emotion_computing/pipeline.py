"""五层编排：一次在线会话的主循环。

数据流（严格按需求文档规定的顺序）：

    感知 → 快系统 → 轻量慢系统 → 记忆 → 行动

节奏（架构文档 §6）：
  * 每一步（默认 1Hz）：感知 → 融合 → 快系统 → 事件检测
  * 每 1s：样本入记忆缓冲
  * 每 5s：慢系统（趋势/预测/可继续性）→ 行动层决策
  * 会话末：写 Episode → 生成复盘报告 → 回写个体画像

基线期（前 baseline_seconds 秒）只做标定，**其样本不进入慢系统与记忆**，
因为标定前后的尺度不同（标定前是原始融合值，标定后是个体内相对量）。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable, Sequence

from .action import ActionPolicy
from .config import Config
from .contracts import Episode, InterventionRecord, StressEvent, StressSample
from .fast_system import EventDetector, FastEstimator
from .memory import EpisodeStore, build_report, summarize
from .memory.retrieval import FEATURE_KEYS, find_similar
from .perception.base import build_sensor
from .perception.fusion import FusionEngine, safe_sigmoid
from .perception.synthetic import SyntheticStressDriver
from .slow_system import CapacityAssessor, StressPredictor

#: 干预后观察多久来评估其效果（秒）
INTERVENTION_WINDOW_S = 60.0


@dataclass
class StepResult:
    t: float
    calibrated: bool
    stress: float | None
    state: str | None
    action: str | None
    events: list[StressEvent]

    def as_dict(self) -> dict:
        return {
            "t": self.t,
            "calibrated": self.calibrated,
            "stress": self.stress,
            "state": self.state,
            "action": self.action,
            "events": [e.as_dict() for e in self.events],
        }


class SessionPipeline:
    def __init__(
        self,
        config: Config | None = None,
        data_dir: str = "data",
        task_label: str = "default",
        driver: SyntheticStressDriver | None = None,
        sensors: dict[str, Any] | None = None,
    ) -> None:
        self.config = config or Config()
        self.store = EpisodeStore(data_dir)
        self.profile = self.store.load_profile()

        # 记忆回写：用历史画像覆盖个体化参数（需求 M-5 / 场景 3）
        if self.profile.sessions > 0:
            self.config.theta_mid = self.profile.theta_mid
            self.config.theta_hi = self.profile.theta_hi
            self.config.tau_rev = self.profile.tau_rev

        self.driver = driver or SyntheticStressDriver()
        self.sensors: dict[str, Any] = (
            sensors
            if sensors is not None
            else {
                name: build_sensor(name, self.config, self.driver)
                for name in ("face", "speech", "text")
            }
        )

        self.fusion = FusionEngine(self.config)
        self.estimator = FastEstimator(self.config)
        self.detector = EventDetector(self.config)
        self.predictor = StressPredictor(self.config)
        self.assessor = CapacityAssessor(self.config)
        self.policy = ActionPolicy(self.config, self.profile)

        self.episode: Episode = self.store.new_episode(task_label)
        self.episode.task_label = task_label

        # 标定后的基线水平（normalized 尺度上的 z≈0 对应值）
        self.baseline_stress: float = safe_sigmoid(
            -self.config.z_target / self.config.z_tau
        )
        self.resilience: float = float(self.profile.resilience)

        self._stress_history: list[tuple[float, float]] = []
        self._last_record_t: float | None = None
        self._last_slow_t: float | None = None
        self._pending_interventions: list[InterventionRecord] = []
        self._events: list[StressEvent] = []

    # ------------------------------------------------------------------
    def backends(self) -> dict[str, str]:
        return {name: getattr(s, "backend", "unknown") for name, s in self.sensors.items()}

    # ------------------------------------------------------------------
    def step(self, payload: dict[str, Any]) -> StepResult:
        cfg = self.config
        t = float(payload.get("t", 0.0))

        observations = tuple(sensor.sense(payload) for sensor in self.sensors.values())

        if not self.fusion.calibrated:
            self.fusion.observe_baseline(observations)
            if t >= cfg.baseline_seconds:
                self.fusion.finalize_baseline()

        frame = self.fusion.fuse(observations, t)
        sample = self.estimator.update(frame)
        events = self.detector.update(sample)
        self._events.extend(events)

        if not self.fusion.calibrated:
            return StepResult(t=t, calibrated=False, stress=None, state=None, action=None,
                              events=events)

        # ---- 标定后：进入记忆与慢系统 ----
        self._stress_history.append((sample.timestamp, sample.smoothed))

        if self._last_record_t is None or (t - self._last_record_t) >= cfg.memory_interval:
            self._record_sample(sample, t)
            self._last_record_t = t

        decision = None
        state = None
        if self._last_slow_t is None or (t - self._last_slow_t) >= cfg.slow_interval:
            state, decision = self._run_slow(sample, t)
            self._last_slow_t = t

        return StepResult(
            t=t,
            calibrated=True,
            stress=sample.smoothed,
            state=state,
            action=(decision.action if decision else None),
            events=events,
        )

    # ------------------------------------------------------------------
    def _record_sample(self, sample: StressSample, t: float) -> None:
        self.episode.samples.append(
            {
                "t": t,
                "raw": round(sample.raw, 5),
                "smoothed": round(sample.smoothed, 5),
                "confidence": round(sample.confidence, 4),
                "contributions": {k: round(v, 4) for k, v in sample.contributions.items()},
            }
        )

    def _run_slow(self, sample: StressSample, t: float):
        times = [x for x, _ in self._stress_history]
        values = [v for _, v in self._stress_history]

        forecast = self.predictor.forecast(times, values, self.baseline_stress)
        assessment = self.assessor.assess(times, values, forecast, self.resilience)

        self.episode.capacity_timeline.append(
            {
                "t": t,
                "state": assessment.state,
                "score": round(assessment.score, 4),
                "forecast": round(forecast.point, 4),
                "slope": round(forecast.slope, 4),
            }
        )

        decision = self.policy.decide(sample, assessment, now=t)

        if decision.action != "continue" and decision.intervention:
            record = InterventionRecord(
                timestamp=t,
                action=decision.action,
                intervention=decision.intervention,
                stress_before=sample.smoothed,
            )
            self._pending_interventions.append(record)
            self.episode.interventions.append(record.as_dict())

        return assessment.state, decision

    # ------------------------------------------------------------------
    def _settle_interventions(self) -> None:
        """用干预后 60s 的紧张度更新每条干预的效果（需求 A-5）。"""
        samples = self.episode.samples
        if not samples:
            return
        for rec_dict in self.episode.interventions:
            ts = float(rec_dict["timestamp"])
            window = [
                float(s["smoothed"])
                for s in samples
                if ts < float(s["t"]) <= ts + INTERVENTION_WINDOW_S
            ]
            rec_dict["stress_after"] = round(sum(window) / len(window), 5) if window else None

    # ------------------------------------------------------------------
    def finalize(self, task_outcome: float | None = None) -> dict:
        cfg = self.config
        self.episode.task_outcome = task_outcome
        self.episode.baseline_mu = self.baseline_stress
        self.episode.baseline_sigma = (
            self.fusion.fused_stats[1] if self.fusion.fused_stats else 0.0
        )
        self.episode.backends = self.backends()
        self.episode.events = [e.as_dict() for e in self._events]

        self._settle_interventions()
        self.episode.summary = summarize(self.episode)

        # ---- 跨会话检索（必须在 append 之前，避免把自己检索进来）----
        index_rows = self.store.load_index()
        query = [float(self.episode.summary.get(k, 0.0) or 0.0) for k in FEATURE_KEYS]
        cross = find_similar(
            index_rows,
            query,
            task_label=self.episode.task_label,
            top_k=3,
            exclude_id=self.episode.episode_id,
        ) if index_rows else []

        # ---- 落盘 ----
        self.store.append_episode(self.episode)

        report = build_report(self.episode, cross_session=cross, backends=self.backends())
        report_path = self.store.write_report(self.episode.episode_id, report.to_markdown())

        # ---- 个性化回写（需求 M-5）----
        self._update_profile()
        self.store.save_profile(self.profile)

        return {
            "episode": self.episode,
            "report": report,
            "report_path": report_path,
            "outputs": sorted(p.name for p in self.store.data_dir.iterdir()),
        }

    # ------------------------------------------------------------------
    def _update_profile(self) -> None:
        summary = self.episode.summary
        self.profile.sessions += 1
        self.profile.baseline_mu = self.baseline_stress

        recovery = summary.get("recovery_time")
        current_resilience = (
            max(0.0, min(1.0, 1.0 - float(recovery) / 300.0))
            if recovery is not None
            else 0.5
        )
        # 指数平滑，避免单次会话剧烈改变画像
        self.profile.resilience = 0.7 * self.profile.resilience + 0.3 * current_resilience

        # 干预有效性：ΔS 越负越有效
        for rec in self.episode.interventions:
            after = rec.get("stress_after")
            if after is None:
                continue
            delta = after - float(rec.get("stress_before", 0.0))
            effect = -delta  # 下降为正收益
            iv_id = rec.get("intervention", "")
            prev = self.profile.intervention_effectiveness.get(iv_id, 0.0)
            self.profile.intervention_effectiveness[iv_id] = 0.7 * prev + 0.3 * effect

    # ------------------------------------------------------------------
    def run_offline(
        self,
        duration: float = 540.0,
        dt: float | None = None,
        task_outcome: float | None = None,
        on_step: Any = None,
    ) -> dict:
        """离线跑完整会话（使用合成/注入的数据源）。"""
        step_dt = float(dt if dt is not None else 1.0 / max(self.config.fast_hz, 1e-6))
        t = 0.0
        while t <= duration + 1e-9:
            result = self.step({"t": t})
            if on_step is not None:
                on_step(result)
            t += step_dt
        return self.finalize(task_outcome)

    def run_stream(
        self, payloads: Iterable[dict[str, Any]], task_outcome: float | None = None
    ) -> dict:
        """跑一个已被外部提供的 payload 流（真实摄像头/麦克风场景）。"""
        for payload in payloads:
            self.step(payload)
        return self.finalize(task_outcome)
