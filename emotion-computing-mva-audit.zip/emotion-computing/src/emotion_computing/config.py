"""全局配置与个体画像的持久化。

所有阈值均为**启发式初值**（需求文档 §8 / 架构文档 §8），需要在真实使用中
按个体校准；不要把它们当成心理学上的通用常数。
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path

from .contracts import PersonalProfile


@dataclass
class Config:
    # ---- 时序 ----
    baseline_seconds: float = 30.0  # 静息基线期
    fast_hz: float = 1.0  # 合成/离线模式下的快系统采样率
    slow_interval: float = 5.0  # 慢系统评估周期（秒）
    memory_interval: float = 1.0  # 记忆缓冲写入间隔（秒）

    # ---- 快系统 ----
    tau_fast: float = 1.5  # EWMA 时间常数（秒）
    theta_spike: float = 0.15  # 尖峰幅度阈值
    spike_sigma_k: float = 3.0  # 尖峰显著性倍数
    t_hi: float = 20.0  # "高位持续"判据时长（秒）

    # ---- 慢系统 ----
    trend_window: float = 60.0  # 趋势估计窗口（秒）
    forecast_horizon: float = 60.0  # 预测视界（秒）
    tau_rev: float = 90.0  # 均值回复时间常数初值（秒）
    theta_mid: float = 0.55  # WATCH 阈值
    theta_hi: float = 0.75  # PAUSE 阈值
    theta_hysteresis: float = 0.05  # 上下阈值分离量，抑制抖动
    t_watch: float = 60.0  # WATCH 持续多久升级为 micro_break

    # ---- 行动层冷却 ----
    cooldown_coach: float = 60.0
    cooldown_micro_break: float = 120.0
    cooldown_pause: float = 90.0

    # ---- 融合权重（可被个体画像覆盖）----
    w_face: float = 0.40
    w_speech: float = 0.35
    w_text: float = 0.25

    # ---- 归一化 ----
    z_target: float = 2.5  # 认为"已明显紧张"的 z 值（静息期 z≈0）
    z_tau: float = 1.2  # sigmoid 的软度；越大越迟钝
    sigma_prior: float = 0.12  # σ 收缩先验：静息期 σ 天然极小，需与之混合
    sigma_floor: float = 0.02  # σ 绝对下界，避免除零
    audio_sr: int = 16000  # 语音采样率

    # ---- 路径 ----
    data_dir: str = "data"

    # ------------------------------------------------------------------
    def modality_weights(self) -> dict[str, float]:
        return {"face": self.w_face, "speech": self.w_speech, "text": self.w_text}

    def to_dict(self) -> dict:
        return asdict(self)

    def save(self, path: str | Path) -> None:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(self.to_dict(), indent=2, ensure_ascii=False), "utf-8")

    @classmethod
    def load(cls, path: str | Path) -> "Config":
        p = Path(path)
        if not p.exists():
            return cls()
        data = json.loads(p.read_text("utf-8"))
        known = {f for f in cls.__dataclass_fields__}  # type: ignore[attr-defined]
        return cls(**{k: v for k, v in data.items() if k in known})


def load_profile(path: str | Path) -> PersonalProfile:
    """加载个体画像；不存在则返回默认画像。"""
    p = Path(path)
    if not p.exists():
        return PersonalProfile()
    try:
        return PersonalProfile.from_dict(json.loads(p.read_text("utf-8")))
    except (json.JSONDecodeError, TypeError):
        return PersonalProfile()


def save_profile(path: str | Path, profile: PersonalProfile) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(
        json.dumps(profile.as_dict(), indent=2, ensure_ascii=False), encoding="utf-8"
    )
